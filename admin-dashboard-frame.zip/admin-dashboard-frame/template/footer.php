</div>
</section>

<script src="<?php echo $url; ?>/vendor/jquery.min.js"></script>
<script src="<?php echo $url; ?>/https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="<?php echo $url; ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $url; ?>/vendor/way_point/jquery.waypoints.js"></script>
<script src="<?php echo $url; ?>/vendor/counter_up/counter_up.js"></script>
<script src="<?php echo $url; ?>/vendor/chart_js/chart.min.js"></script>
<script src="<?php echo $url; ?>/vendor/data_table/jquery.dataTables.min.js"></script>
<script src="<?php echo $url; ?>/vendor/data_table/dataTables.bootstrap4.min.js"></script>

<script src="<?php echo $url; ?>/vendor/summer_note/summernote.min.js"></script>
<script src="<?php echo $url; ?>/assets/js/app.js"></script>

<script src="<?php echo $url; ?>/assets/js/dashboard.js"></script>
</body>
</html>